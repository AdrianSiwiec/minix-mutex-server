#!/bin/sh

# simply runs all tests

cd /mnt/minix/testy
echo TEST NR 1 ; ./test1.sh
echo TEST NR 2 ; ./test2.sh
echo TEST NR 3 ; ./test3.sh
echo TEST NR 4 ; ./test4.sh